import pandas as pd
from transformers import AutoModel, AutoTokenizer
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoModelForSeq2SeqLM, GenerationConfig
from datasets import load_dataset
from trl import PPOTrainer, PPOConfig, AutoModelForSeq2SeqLMWithValueHead
from trl import create_reference_model
import torch
from peft import PeftModel, prepare_model_for_kbit_training, PeftConfig, get_peft_model, LoraConfig, TaskType
from transformers import BitsAndBytesConfig
from transformers import AutoModelForSeq2SeqLM
from peft import LoraConfig, get_peft_model, prepare_model_for_int8_training, TaskType
from sklearn.model_selection import train_test_split
from datasets import Dataset
import os
from dataclasses import dataclass, field
from typing import Dict, Optional
import torch
from datasets import Dataset, load_dataset
from peft import LoraConfig
from transformers import AutoModelForCausalLM, AutoTokenizer, HfArgumentParser, TrainingArguments
from trl import DPOTrainer
from transformers.models.bart.configuration_bart import BartConfig
from transformers import (
    BartTokenizerFast,
    AdamW
)
from transformers import Seq2SeqTrainer, Seq2SeqTrainingArguments,TrainingArguments
from trl import DPOTrainer, AutoModelForSeq2SeqLMWithValueHead
from transformers import Seq2SeqTrainer, Seq2SeqTrainingArguments,TrainingArguments
from trl import DPOTrainer, AutoModelForSeq2SeqLMWithValueHead
from transformers import GPT2LMHeadModel, GPT2Tokenizer
from datasets import load_dataset
from nltk.translate import bleu_score
from rouge_score import rouge_scorer
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.tokenize import word_tokenize
from nltk.translate.meteor_score import meteor_score
# Define a function to generate text using the pretrained model
from transformers import GenerationConfig
NUM_BEAMS = 3
EARLY_STOPPING = True
NO_REPEAT_NGRAM_SIZE = 3
gen_kwargs = {
    'num_beams': NUM_BEAMS,
    'max_length': 265, 
    'early_stopping': EARLY_STOPPING,
    'no_repeat_ngram_size': NO_REPEAT_NGRAM_SIZE
}
local_model_path="/mnt/Data/akashghosh/MDS/Model/DPOwithmorebetaupdated/checkpoint-500"

model =  AutoModelForSeq2SeqLM.from_pretrained(local_model_path, 
                                               low_cpu_mem_usage=True,
                                               torch_dtype=torch.float32,
                                               load_in_4bit=False)
tokenizer = AutoTokenizer.from_pretrained('facebook/bart-base')




def generate_text(prompt):
    input_ids = tokenizer(prompt, return_tensors='pt')
    output = model.generate(input_ids["input_ids"],**gen_kwargs)
    generated_text = tokenizer.decode(output[0], skip_special_tokens=True)
    return generated_text
   

# Define a function to calculate BLEU, ROUGE, and BERT scores
def calculate_scores(generated_text, reference_text):
    # BLEU Scores
    bleu_1 = bleu_score.sentence_bleu([reference_text.split()], generated_text.split(), weights=(1, 0, 0, 0))
    bleu_2 = bleu_score.sentence_bleu([reference_text.split()], generated_text.split(), weights=(0.5, 0.5, 0, 0))
    bleu_3 = bleu_score.sentence_bleu([reference_text.split()], generated_text.split(), weights=(0.33, 0.33, 0.33, 0))
    bleu_4 = bleu_score.sentence_bleu([reference_text.split()], generated_text.split(), weights=(0.25, 0.25, 0.25, 0.25))

    # ROUGE Scores
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    rouge_scores = scorer.score(reference_text, generated_text)
    rouge_1 = rouge_scores['rouge1'].fmeasure
    rouge_2 = rouge_scores['rouge2'].fmeasure
    rouge_l = rouge_scores['rougeL'].fmeasure
    #meteor=meteor_score([word_tokenize(generated_text)], word_tokenize(reference_text))
    return bleu_1, bleu_2, bleu_3, bleu_4, rouge_1, rouge_2, rouge_l

bleu1_scores = []
bleu2_scores= []
bleu3_scores=[]
bleu4_scores=[]
rouge1_scores = []
rouge2_scores = []
rougel_scores = []
meteor_scores = []
gen_output=[]
import pandas as pd
test_data=pd.read_csv("multimodal_clinical_dailogsumm_test.csv")

for index, row in test_data.iterrows():
    prompt = row['Hindi_Prompt_format']
    print(index)
    #print(prompt)
    generated_text = generate_text(prompt)
    print("Generated text:")
    print(generated_text)
    print("Ground truth")
    ground_truth_text = row['Overall_Summary']
    print(ground_truth_text)
    # Assuming calculate_scores() returns the BLEU and ROUGE scores
    bleu_1, bleu_2, bleu_3, bleu_4, rouge_1, rouge_2, rouge_l = calculate_scores(generated_text, ground_truth_text)
    
    # Assuming you have lists to store the scores
    bleu1_scores.append(bleu_1)
    bleu2_scores.append(bleu_2)
    bleu3_scores.append(bleu_3)
    bleu4_scores.append(bleu_4)
    rouge1_scores.append(rouge_1)
    rouge2_scores.append(rouge_2)
    rougel_scores.append(rouge_l)
    gen_output.append(generated_text)
    dictu = {'geno': gen_output}
    df = pd.DataFrame(dictu)
    #df.to_csv('/mnt/Data/akashghosh/MDS/IBMData/generated_output_newbeta4updateddata.csv',index=False)
    
#gen_output.to_csv("generated_output_dpo.csv",index=False)  
#dictu = {'geno': gen_output}
#df = pd.DataFrame(dictu)
# saving the dataframe
#df.to_csv('generated_output_dpo.csv',index=False)
avg_bleu_1 = sum(bleu1_scores) / len(bleu1_scores)
avg_bleu_2 = sum(bleu2_scores) / len(bleu2_scores)
avg_bleu_3 = sum(bleu3_scores) / len(bleu3_scores)
avg_bleu_4 = sum(bleu4_scores) / len(bleu4_scores)
avg_rouge_1 = sum(rouge1_scores) / len(rouge1_scores)
avg_rouge_2 = sum(rouge2_scores) / len(rouge2_scores)
avg_rouge_l = sum(rougel_scores) / len(rougel_scores)

# Print average scores
print("Average BLEU-1:", avg_bleu_1)
print("Average BLEU-2:", avg_bleu_2)
print("Average BLEU-3:", avg_bleu_3)
print("Average BLEU-4:", avg_bleu_4)
print("Average ROUGE-1:", avg_rouge_1)
print("Average ROUGE-2:", avg_rouge_2)
print("Average ROUGE-L:", avg_rouge_l)   






































